import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PostulacionesService } from 'src/app/services/postulaciones.service';
import { AlertController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-detalles',
  templateUrl: './detalles.page.html',
  styleUrls: ['./detalles.page.scss'],
})
export class DetallesPage implements OnInit {
  postulacion: any;
  qrdata: string ='';

  constructor(
    private route: ActivatedRoute,
    private postulacionesService: PostulacionesService,
    private router: Router,
    private alertcontroller: AlertController,
    private toast: ToastController
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    
    if (id) {
      this.postulacionesService.getPostulacion(id).subscribe(postulacion => {
        this.postulacion = postulacion;
        this.qrdata = ''
      });
    }
    
  }

  async generarCodigoQR() {
    this.qrdata = this.postulacion.id + this.postulacion.nombrePublicacion + this.postulacion.codigo + this.postulacion.fecha +
      this.postulacion.hora + this.postulacion.monto + this.postulacion.descripcion;
    console.log(this.qrdata);
  }
  async showToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000
    });
    toast.present();
  }

  volver() {
    this.router.navigate(['/tabs/tab2']); 
  }
}