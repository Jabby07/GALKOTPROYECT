import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApipublicacionesService } from 'src/app/services/apipublicaciones.service';
import { AuthService } from 'src/app/services/auth.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-trabajos',
  templateUrl: './trabajos.page.html',
  styleUrls: ['./trabajos.page.scss'],
})
export class TrabajosPage implements OnInit {
  publicacion: any;
  qrdata: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiPubli: ApipublicacionesService,
    private authService: AuthService,
    private toast: ToastController
  ) {
    this.qrdata = '';
  }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.apiPubli.getPublicacionById(id).subscribe(
        (data) => {
          this.publicacion = data;
        },
        (error) => {
          console.error('Error al obtener la publicación:', error);
          if (error.status === 404) {
            alert('Publicación no encontrada');
            this.router.navigate(['/tabs/tab1']);
          }
        }
      );
    } else {
      console.error('ID de publicación no proporcionado');
    }
  }

  async postularTrabajo() {
    if (!this.authService.isLoggedIn()) {
      this.showToast('Debes iniciar sesión para postularte');
      return;
    }
    this.apiPubli.checkIfPostulado(this.publicacion.codigo).subscribe(
      (data) => {
        if (data.length > 0) {
          this.showToast('Este trabajo ya ha sido postulado');
        } else {
          const postulacion = {
            codigo: this.publicacion.codigo,
            usuario: sessionStorage.getItem('username'),
            nombrePublicacion: this.publicacion.nombrePublicacion,
            fecha: this.publicacion.fecha,
            hora: this.publicacion.hora,
            monto: this.publicacion.monto,
            descripcion: this.publicacion.descripcion,
            postulante: sessionStorage.getItem('rut')
            
          };

          this.apiPubli.postularTrabajo(postulacion).subscribe(
            (result) => {
              this.showToast('Te Has postulado correctamente');
              this.router.navigate(['/tabs/tab2']);
            },
            (error) => {
              console.error('Error al postular el trabajo:', error);
              this.showToast('Error al postular el trabajo');
            }
          );
        }
      },
      (error) => {
        console.error('Error al verificar la postulación:', error);
      }
    );
  }

  async showToast(msg: string) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000
    });
    toast.present();
  }

  volver() {
    this.router.navigate(['/tabs/tab1']);
  }
}
