import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { IngresoPage } from '../ingreso/ingreso.page';
import { RegistroPage } from '../registro/registro.page';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: './login.page.html',
    styleUrls: ['./login.page.scss'],
    standalone: false
})
export class LoginPage  {

  constructor(private modalcontroller: ModalController,private router: Router) { }

  ingreso() {
    this.router.navigateByUrl("/ingreso");
  }


  registrar() {
    this.router.navigateByUrl("/registro");
  }
}