import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { ImageService } from 'src/app/services/image.service';


@Component({
    selector: 'app-modificar',
    templateUrl: './modificar.page.html',
    styleUrls: ['./modificar.page.scss'],
    standalone: false
})
export class ModificarPage implements OnInit{

  imageSrc: string | ArrayBuffer | null = null;
  perfilForm: FormGroup;
  UsuarioActual: any;

  constructor(private imageService: ImageService,
              private authService: AuthService,
              private route: ActivatedRoute,
              private router: Router,
              private alertcontroller: AlertController,
              private formBuilder: FormBuilder) {
                        this.perfilForm = this.formBuilder.group({
                        username: ['', [Validators.required, Validators.minLength(6)]],
                        email: ['', [Validators.required, Validators.email]],
                        rut: [''],
                        imagen: [''] 
                     });
                     this.imageSrc = localStorage.getItem('imageSrc');
 }

 ngOnInit() {
  const userId = this.route.snapshot.paramMap.get('id');
  if (userId) {
    this.authService.getPerfil(userId).subscribe(user => {
      this.UsuarioActual = user;
      this.perfilForm.patchValue({
        username: this.UsuarioActual.username,
        email: this.UsuarioActual.email,
        rut: this.UsuarioActual.rut,
        imagen: this.UsuarioActual.imagen
      });
    });
  }
}

async guardarCambios() {
  if (this.perfilForm.valid) {
    const updatedUser = {
      ...this.UsuarioActual,
      ...this.perfilForm.value
    };
    this.authService.updatePerfil(updatedUser.id, updatedUser).subscribe(async () => {
      const alert = await this.alertcontroller.create({
        header: 'Su perfil ha sido modificado con exito',
        message: 'Debe volver a iniciar sesion',
        buttons: [{
          text: 'OK',
          handler: () => {
            this.authService.logout(); // Redirigir a la página de inicio de sesión
          }
        }]
      });

      await alert.present();
    });
  }
}
onImageSelected(event: Event): void {
  const input = event.target as HTMLInputElement;
  if (input && input.files && input.files[0]) {
    const file = input.files[0];

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;

        // Guarda la imagen en el servicio o en localStorage
        this.imageService.setImageSrc(this.imageSrc); // Usando servicio

        // O guarda en localStorage
        localStorage.setItem('imageSrc', this.imageSrc as string);
      };
      reader.readAsDataURL(file);  // Lee el archivo como una URL de datos
    } else {
      console.log('El archivo no es una imagen');
    }
  }
}



  volver(){
    this.router.navigateByUrl("/tabs/tab4");
  }
}
