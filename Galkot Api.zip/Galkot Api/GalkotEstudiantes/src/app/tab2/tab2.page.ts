import { Component, OnInit } from '@angular/core';
import { PostulacionesService } from 'src/app/services/postulaciones.service';
import { ToastController } from '@ionic/angular'; // Importar el ToastController

@Component({
  selector: 'app-tab2',
  templateUrl: './tab2.page.html',
  styleUrls: ['./tab2.page.scss'],
})
export class Tab2Page implements OnInit {

  postulaciones: any[] = [];
  estadoFiltro: string = ''; // Variable para el filtro de estado

  constructor(
    private postulacionesService: PostulacionesService,
    private toastController: ToastController // Inyectar el ToastController
  ) { }

  ngOnInit() {
    this.cargarPostulaciones();
  }

  cargarPostulaciones() {
    this.postulacionesService.getPostulaciones().subscribe(data => {
      this.postulaciones = data;
    });
  }

  filtrarPostulaciones() {
    if (this.estadoFiltro) {
      this.postulacionesService.getPostulaciones().subscribe(data => {
        this.postulaciones = data.filter(postulacion => postulacion.estado === this.estadoFiltro);
      });
    } else {
      this.cargarPostulaciones();  // Si no hay filtro, cargamos todas las postulaciones
    }
  }

  async cancelarPostulacion(id: string) { // Añadir 'async' aquí
    this.postulacionesService.eliminarPostulacion(id).subscribe(() => {
      // Actualiza la lista local después de eliminar
      this.postulaciones = this.postulaciones.filter(postulacion => postulacion.id !== id);
      console.log(`Postulación con ID ${id} cancelada.`);
  
      // Mostrar mensaje de éxito
      this.toastController.create({
        message: 'Tu postulación fue cancelada correctamente',
        duration: 2000,
        color: 'success', // Color verde para indicar éxito
        position: 'top' // Posición del mensaje
      }).then(toast => toast.present());
    });
  }
}
