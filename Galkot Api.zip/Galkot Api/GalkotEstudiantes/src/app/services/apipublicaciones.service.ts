import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApipublicacionesService {
  private apiUrl = 'http://localhost:3000/publicaciones'; 
  private postulacionesUrl = 'http://localhost:3000/postulaciones';

  constructor(private http: HttpClient) { }


  getPublicaciones(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  getPublicacionById(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  createPublicacion(publicacion: any): Observable<any> {
    return this.http.post(`${this.apiUrl}`, publicacion);
  }

  updatePublicacion(id: string, publicacion: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, publicacion);
  }

  eliminarPublicacion(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  checkIfPostulado(codigo: string): Observable<any> {
    return this.http.get(`${this.postulacionesUrl}?codigo=${codigo}`);
  }

  postularTrabajo(postulacion: any): Observable<any> {
    return this.http.post(this.postulacionesUrl, postulacion);
  }
}