import { TestBed } from '@angular/core/testing';

import { ApipublicacionesService } from './apipublicaciones.service';

describe('ApipublicacionesService', () => {
  let service: ApipublicacionesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApipublicacionesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
