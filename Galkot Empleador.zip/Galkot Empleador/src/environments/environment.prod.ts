export const environment = {
  production: true,
  apiUrl:'https://galkotproyect.onrender.com'
};
