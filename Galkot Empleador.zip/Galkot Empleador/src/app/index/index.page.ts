import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ApipublicacionesService } from '../services/apipublicaciones.service';
import { Publicacion } from 'src/interfaces/publicacion'; // Ajusta la ruta según donde guardaste la interfaz

@Component({
  selector: 'app-index',
  templateUrl: './index.page.html',
  styleUrls: ['./index.page.scss'],
})
export class IndexPage implements OnInit {
  images = [
    'assets/img1.jpg',
    'assets/img2.jpg',
    'assets/img3.jpg',
  ];
  currentIndex = 0;
  currentImage = this.images[this.currentIndex];

  username: string = '';
  publicaciones: Publicacion[] = [];
  selectedOrder: string = 'alfabetico';

  constructor(
    private alertcontroller: AlertController,
    private router: Router,
    private authService: AuthService,
    private apiPubli: ApipublicacionesService
  ) {}

  ngOnInit() {
    this.username = sessionStorage.getItem('username') || '';

    setInterval(() => {
      this.currentIndex++;
      if (this.currentIndex >= this.images.length) {
        this.currentIndex = 0;
      }
      this.currentImage = this.images[this.currentIndex];
    }, 3000); // Cambia la imagen cada 3 segundos

    this.cargarPublicaciones();
  }

  cargarPublicaciones() {
    this.apiPubli.getPublicaciones().subscribe(
      (data: Publicacion[]) => {
        this.publicaciones = data.map((pub: Publicacion) => ({
          ...pub,
          id: pub.id // Asegúrate de que 'idPublicacion' sea la propiedad correcta
        }));
        this.ordenarPublicaciones(); // Ordenar publicaciones después de cargar
      },
      (error) => {
        console.error('Error al obtener las publicaciones:', error);
      }
    );
  }

  ordenarPublicaciones() {
    if (this.selectedOrder === 'alfabetico') {
      this.publicaciones.sort((a, b) => a.nombrePublicacion.localeCompare(b.nombrePublicacion));
    } else if (this.selectedOrder === 'fecha') {
      this.publicaciones.sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());
    } else if (this.selectedOrder === 'monto') {
      this.publicaciones.sort((a, b) => b.monto - a.monto);
    }
  }

  verDetalles(id: string) {
    if (id) {
      this.router.navigate(['/detalle-publicacion', id]);
    } else {
      console.error('ID de la publicación no proporcionado o es undefined');
    }
  }
}
