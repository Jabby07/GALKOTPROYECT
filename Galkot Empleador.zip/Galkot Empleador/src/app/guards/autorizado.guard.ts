import { CanActivateFn } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ToastController } from '@ionic/angular';
import { UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';


@Injectable({ providedIn: 'root' })
export class AutorizadoGuard {

  constructor(private authservice:AuthService,
              private toast: ToastController,
              private router: Router,){

}


  canActivate():
    
    | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if (!this.authservice.isLoggedIn()){
        this.showToast('Debe iniciar sesion..');
        this.router.navigateByUrl("/inicio");
        return false;
      }
      else{
        this.authservice.isLoggedIn();
        return true;
      }
    }

    async showToast(msg: any){
      const toast = await this.toast.create({
        message:msg,
        duration:3000
      });
      toast.present();
    }
}
