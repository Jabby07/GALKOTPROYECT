import { Component, OnInit } from '@angular/core';
import { CapacitorBarcodeScanner } from '@capacitor/barcode-scanner';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { BarcodeScanningModalComponent } from './barcode-scanning-modal.component';
import { BarcodeScanner, LensFacing } from '@capacitor-mlkit/barcode-scanning';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-lectorqr',
  templateUrl: './lectorqr.page.html',
  styleUrls: ['./lectorqr.page.scss'],
})
export class LectorqrPage implements OnInit{

  segment = 'scan';
  scanResult= '';

  constructor(private modalController: ModalController, 
              private platform: Platform,
              private router: Router
  ) {}

  ngOnInit(): void {
    if(this.platform.is('capacitor')){
      BarcodeScanner.isSupported().then();
      BarcodeScanner.checkPermissions().then();
      BarcodeScanner.removeAllListeners();
    }
  }


  async startScan() {
    const modal = await this.modalController.create({
    component: BarcodeScanningModalComponent,
    cssClass:'barcode-scanning-modal',
    showBackdrop: false,
    componentProps: { 
      format: [],
      LensFacing: LensFacing.Back
     }
    });
  
    await modal.present();
    
    const {data}=await modal.onWillDismiss();

    if(data){
      this.scanResult = data?.barcode?.displayValue;
    }
  }


  volver(){
    this.router.navigateByUrl("/index");
  }
}
