import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
import { AutorizadoGuard } from '../guards/autorizado.guard';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'index',
        loadChildren: () => import('../index/index.module').then( m => m.IndexPageModule),
        canActivate: [AutorizadoGuard]
      },
      {
        path: 'perfil',
        loadChildren: () => import('../perfil/perfil.module').then( m => m.PerfilPageModule),
        canActivate: [AutorizadoGuard]
      },
      {
        path: 'pagos',
        loadChildren: () => import('../pagos/pagos.module').then( m => m.PagosPageModule),
        canActivate: [AutorizadoGuard]
      },
      {
        path: 'lectorqr',
        loadChildren: () => import('../lectorqr/lectorqr.module').then( m => m.LectorqrPageModule),
        canActivate: [AutorizadoGuard]
      },
      {
        path: 'publicar',
        loadChildren: () => import('../publicar/publicar.module').then( m => m.PublicarPageModule),
        canActivate: [AutorizadoGuard]
      },
      {
        path: '',
        redirectTo: '../tabs/index',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/index',
    pathMatch: 'full'
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
})
export class TabsPageRoutingModule {}
